#!/usr/bin/env python3
"""কণ্ঠ share card: dark radio booth, one amber orb, shaped Bengali title."""
import math
import numpy as np
import uharfbuzz as hb
import freetype
from PIL import Image, ImageDraw, ImageFilter

W, H = 2400, 1260
FONT = "/workspace/.grok/fonts/NotoSansBengali-Black.ttf"
TEXT = "কণ্ঠ"
AMBER = np.array([227, 155, 58], dtype=np.float32)
PAPER = np.array([244, 239, 230], dtype=np.float32)
COPPER = (196, 118, 58)
COPPER_DK = (112, 62, 30)
BG = np.array([20, 18, 14], dtype=np.float32)

def shaped_mask(px_size: int) -> Image.Image:
    blob = hb.Blob.from_file_path(FONT)
    face = hb.Face(blob)
    font = hb.Font(face)
    upem = face.upem
    font.scale = (upem, upem)
    buf = hb.Buffer()
    buf.add_str(TEXT)
    buf.guess_segment_properties()
    hb.shape(font, buf)
    ft = freetype.Face(FONT)
    ft.set_char_size(px_size * 64)
    glyphs = []
    pen_x = 0
    pen_y = 0
    minx = miny = 10**9
    maxx = maxy = -10**9
    for info, p in zip(buf.glyph_infos, buf.glyph_positions):
        ft.load_glyph(info.codepoint, freetype.FT_LOAD_RENDER)
        bmp = ft.glyph.bitmap
        x = pen_x + ft.glyph.bitmap_left + int(round(p.x_offset * px_size / upem))
        y_top = pen_y - ft.glyph.bitmap_top - int(round(p.y_offset * px_size / upem))
        if bmp.width and bmp.rows:
            pitch = bmp.pitch
            raw = bytes(bmp.buffer)
            # pitch may exceed width
            if pitch != bmp.width:
                rows = []
                for row in range(bmp.rows):
                    start = row * pitch
                    rows.append(raw[start : start + bmp.width])
                raw = b"".join(rows)
            glyphs.append((x, y_top, bmp.width, bmp.rows, raw))
            minx = min(minx, x)
            miny = min(miny, y_top)
            maxx = max(maxx, x + bmp.width)
            maxy = max(maxy, y_top + bmp.rows)
        pen_x += int(round(p.x_advance * px_size / upem))
        pen_y -= int(round(p.y_advance * px_size / upem))
    pad = 8
    w = maxx - minx + pad * 2
    h = maxy - miny + pad * 2
    im = Image.new("L", (w, h), 0)
    for x, y, bw, bh, raw in glyphs:
        g = Image.frombytes("L", (bw, bh), raw)
        im.paste(Image.eval(g, lambda v: v), (x - minx + pad, y - miny + pad), g)
    return im

def main():
    rng = np.random.default_rng(7)
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    img = np.empty((H, W, 3), dtype=np.float32)
    img[:] = BG

    # Soft acoustic panels, low contrast so the booth reads without striping.
    panel = 180
    for i, x0 in enumerate(range(0, W, panel)):
        x1 = min(W, x0 + panel - 4)
        lift = 6 if i % 2 == 0 else -2
        img[:, x0:x1, 0] += lift + 1
        img[:, x0:x1, 1] += lift
        img[:, x0:x1, 2] += max(lift - 2, -4)
        img[:, x0 : min(W, x0 + 2)] *= 0.55

    # Ceiling darker, a little air in the middle
    ceil = np.clip(1 - yy / (H * 0.55), 0, 1)
    img *= (1 - 0.28 * ceil)[..., None]
    floor = np.clip((yy - H * 0.70) / (H * 0.30), 0, 1)
    img *= (1 - 0.38 * floor)[..., None]

    ox, oy = W / 2.0, 300.0
    r = np.sqrt((xx - ox) ** 2 + (yy - oy) ** 2)
    pool = np.clip(1 - r / 1100, 0, 1) ** 1.55
    img += pool[..., None] * AMBER * 0.30
    img += pool[..., None] * PAPER * 0.035

    nx = (xx - W / 2) / (W * 0.58)
    ny = (yy - H * 0.42) / (H * 0.62)
    vig = np.clip(nx * nx + ny * ny, 0, 1)
    img *= (1 - 0.58 * np.power(vig, 1.12))[..., None]

    grain = rng.normal(0, 2.4, (H, W, 1)).astype(np.float32)
    img += grain
    dust = (rng.random((H, W)) > 0.99935) & (r < 820)
    img[dust] = np.minimum(img[dust] + PAPER * 0.45, 255)

    img = np.clip(img, 0, 255).astype(np.uint8)
    base = Image.fromarray(img, "RGB").convert("RGBA")

    # Copper booth frame
    frame = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    fd = ImageDraw.Draw(frame)
    m = 52
    fd.rounded_rectangle([m, m, W - 1 - m, H - 1 - m], radius=40, outline=COPPER + (225,), width=9)
    fd.rounded_rectangle(
        [m + 20, m + 20, W - 1 - m - 20, H - 1 - m - 20],
        radius=28,
        outline=COPPER_DK + (190,),
        width=3,
    )
    arm, thick = 86, 12
    for cx, cy, sx, sy in (
        (m - 4, m - 4, 1, 1),
        (W - m + 4, m - 4, -1, 1),
        (m - 4, H - m + 4, 1, -1),
        (W - m + 4, H - m + 4, -1, -1),
    ):
        fd.line([(cx, cy), (cx + sx * arm, cy)], fill=COPPER + (245,), width=thick)
        fd.line([(cx, cy), (cx, cy + sy * arm)], fill=COPPER + (245,), width=thick)
    base = Image.alpha_composite(base, frame)

    # Flanking soundboards, dim, beside the orb — never under the title.
    board = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(board)

    def soundboard(x, y, cols=7):
        bw = cols * 52 + 36
        bh = 300
        bd.rounded_rectangle([x, y, x + bw, y + bh], radius=16, fill=(10, 9, 8, 150), outline=COPPER_DK + (150,), width=2)
        for i in range(cols):
            fx = x + 22 + i * 52
            bd.rounded_rectangle([fx + 14, y + 28, fx + 22, y + 210], radius=4, fill=(40, 30, 20, 230))
            cap_y = y + 48 + ((i * 29) % 130)
            bd.rounded_rectangle([fx + 6, cap_y, fx + 30, cap_y + 26], radius=5, fill=COPPER + (235,))
            bd.rectangle([fx + 11, cap_y + 10, fx + 25, cap_y + 15], fill=(244, 239, 230, 200))
            for k in range(6):
                lit = k < (2 + (i * 3) % 4)
                if lit and k >= 4:
                    col = (186, 78, 46, 210)
                elif lit:
                    col = (227, 155, 58, 220)
                else:
                    col = (42, 32, 22, 140)
                bd.rounded_rectangle([fx + 10, y + 226 + k * 10, fx + 26, y + 232 + k * 10], radius=2, fill=col)
        return bw

    soundboard(128, 150)
    soundboard(2400 - 128 - (7 * 52 + 36), 150)
    base = Image.alpha_composite(base, board)

    # Bloom
    bloom = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bl = ImageDraw.Draw(bloom)
    for rad, alpha, col in (
        (720, 20, (227, 155, 58)),
        (480, 42, (227, 155, 58)),
        (320, 80, (232, 176, 90)),
        (220, 100, (244, 214, 150)),
    ):
        bl.ellipse([ox - rad, oy - rad, ox + rad, oy + rad], fill=col + (alpha,))
    bloom = bloom.filter(ImageFilter.GaussianBlur(26))
    base = Image.alpha_composite(base, bloom)

    # Shaded amber sphere
    R = 168
    dx = (xx - ox) / R
    dy = (yy - oy) / R
    disk = dx * dx + dy * dy <= 1.0
    lx, ly, lz = -0.42, -0.58, 0.70
    ln = math.sqrt(lx * lx + ly * ly + lz * lz)
    lx, ly, lz = lx / ln, ly / ln, lz / ln
    dz = np.sqrt(np.clip(1 - np.clip(dx * dx + dy * dy, 0, 1), 0, 1))
    ndotl = np.clip(dx * lx + dy * ly + dz * lz, 0, 1)
    body = AMBER * (0.25 + 0.78 * ndotl)[..., None]
    spec = np.clip((ndotl - 0.84) / 0.16, 0, 1) ** 1.5
    body = body * (1 - 0.7 * spec)[..., None] + PAPER * (0.9 * spec)[..., None]
    rim = np.clip(1 - dz, 0, 1) ** 1.4
    body = body * (1 - 0.4 * rim)[..., None] + np.array([150, 78, 36], dtype=np.float32) * (0.5 * rim)[..., None]
    sp = np.zeros((H, W, 4), dtype=np.float32)
    sp[disk, :3] = np.clip(body[disk], 0, 255)
    edge = np.clip((1 - (dx * dx + dy * dy)) * 22, 0, 1)
    sp[..., 3] = np.where(disk, 255 * edge, 0)
    base = Image.alpha_composite(base, Image.fromarray(sp.astype(np.uint8), "RGBA"))

    # Copper ring + faint voice arcs
    ring = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    rr = 198
    rd.ellipse([ox - rr, oy - rr, ox + rr, oy + rr], outline=COPPER + (255,), width=16)
    rd.ellipse([ox - rr - 12, oy - rr - 12, ox + rr + 12, oy + rr + 12], outline=COPPER_DK + (170,), width=4)
    rd.ellipse([ox - rr + 26, oy - rr + 26, ox + rr - 26, oy + rr - 26], outline=(244, 224, 190, 80), width=2)
    for i, rad in enumerate((290, 370, 450)):
        a = 64 - i * 16
        rd.arc([ox - rad, oy - rad, ox + rad, oy + rad], start=205, end=335, fill=(227, 155, 58, a), width=5)
        rd.arc([ox - rad, oy - rad, ox + rad, oy + rad], start=25, end=155, fill=(227, 155, 58, a), width=5)
    base = Image.alpha_composite(base, ring)

    # Title — shaped কণ্ঠ, paper fill, copper edge
    mask = shaped_mask(675)
    # ink bbox inside padded mask
    bb = mask.getbbox()
    glyph = mask.crop(bb)
    tw, th = glyph.size
    print("title ink", tw, th, "ratio", round(tw / th, 3))
    ring_bottom = oy + rr
    title_top = ring_bottom + 36
    if title_top + th > H - 78:
        title_top = H - 78 - th
    tx = int((W - tw) / 2)
    ty = int(title_top)
    print(
        "place",
        tx,
        ty,
        "right",
        tx + tw,
        "bottom",
        ty + th,
        "margins LRTB",
        tx,
        W - (tx + tw),
        ty,
        H - (ty + th),
    )

    title_layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    # soft shadow
    shadow = glyph.filter(ImageFilter.GaussianBlur(14))
    sh_rgba = Image.new("RGBA", glyph.size, (28, 12, 6, 0))
    sh_rgba.putalpha(shadow.point(lambda v: int(v * 0.72)))
    title_layer.paste(sh_rgba, (tx, ty + 12), sh_rgba)
    # copper edge via dilation
    dil = glyph.filter(ImageFilter.MaxFilter(9))
    copper_im = Image.new("RGBA", glyph.size, COPPER + (255,))
    title_layer.paste(copper_im, (tx, ty), dil)
    paper_im = Image.new("RGBA", glyph.size, (244, 239, 230, 255))
    title_layer.paste(paper_im, (tx, ty), glyph)
    base = Image.alpha_composite(base, title_layer)

    final = base.convert("RGB").resize((1200, 630), Image.Resampling.LANCZOS)
    final.save("/workspace/.grok/card-raw.png", "PNG")
    print("wrote card-raw", final.size)

if __name__ == "__main__":
    main()
