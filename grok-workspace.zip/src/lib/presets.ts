export type FilterSpec = {
  type: BiquadFilterType;
  freq: number;
  q: number;
  gain: number;
};

export type Effect = {
  id: string;
  name: string;
  hint: string;
  semitones: number;
  ring: number;
  ringHz: number;
  filter: FilterSpec;
  delay: number;
  feedback: number;
  drive: number;
};

export type PresetVoice = {
  id: string;
  name: string;
  line: string;
  src: string;
};

export const EFFECTS: Effect[] = [
  {
    id: "dry",
    name: "রেগুলার",
    hint: "হোম",
    semitones: 0,
    ring: 0,
    ringHz: 40,
    filter: { type: "peaking", freq: 1000, q: 1, gain: 0 },
    delay: 0,
    feedback: 0,
    drive: 1,
  },
  {
    id: "deep",
    name: "গম্ভীর",
    hint: "নিচু",
    semitones: -5,
    ring: 0,
    ringHz: 40,
    filter: { type: "lowshelf", freq: 240, q: 0.7, gain: 7 },
    delay: 0,
    feedback: 0,
    drive: 1.4,
  },
  {
    id: "chip",
    name: "চিকন",
    hint: "উঁচু",
    semitones: 7,
    ring: 0,
    ringHz: 40,
    filter: { type: "highshelf", freq: 2200, q: 0.7, gain: 5 },
    delay: 0,
    feedback: 0,
    drive: 1.2,
  },
  {
    id: "robot",
    name: "রোবট",
    hint: "ধাতব",
    semitones: -1,
    ring: 0.92,
    ringHz: 38,
    filter: { type: "bandpass", freq: 1400, q: 0.85, gain: 0 },
    delay: 0.04,
    feedback: 0.12,
    drive: 2.4,
  },
  {
    id: "radio",
    name: "রেডিও",
    hint: "ব্যান্ড",
    semitones: -1,
    ring: 0,
    ringHz: 40,
    filter: { type: "bandpass", freq: 1600, q: 0.9, gain: 0 },
    delay: 0,
    feedback: 0,
    drive: 3,
  },
  {
    id: "echo",
    name: "প্রতিধ্বনি",
    hint: "ফাঁকা ঘর",
    semitones: 0,
    ring: 0,
    ringHz: 40,
    filter: { type: "peaking", freq: 1800, q: 0.8, gain: 3 },
    delay: 0.26,
    feedback: 0.38,
    drive: 1,
  },
  {
    id: "ghost",
    name: "ভূত",
    hint: "দূর",
    semitones: -4,
    ring: 0.15,
    ringHz: 18,
    filter: { type: "highpass", freq: 500, q: 0.7, gain: 0 },
    delay: 0.32,
    feedback: 0.28,
    drive: 1.3,
  },
];

export const PRESETS: PresetVoice[] = [
  { id: "rush", name: "রাশ", line: "ডান দিক ফাঁকা", src: "/voices/rush.mp3" },
  { id: "hush", name: "চুপ", line: "পায়ের শব্দ", src: "/voices/hush.mp3" },
  { id: "hype", name: "জোশ", line: "আরেকটা রাউন্ড", src: "/voices/hype.mp3" },
  { id: "medic", name: "দাঁড়া", line: "নড়িস না", src: "/voices/medic.mp3" },
  { id: "zone", name: "জোন", line: "ভিতরে ঢুক", src: "/voices/zone.mp3" },
  { id: "cover", name: "কভার", line: "তুই এগো", src: "/voices/cover.mp3" },
  { id: "hello", name: "হ্যালো", line: "শুনতে পাচ্ছ?", src: "/voices/hello.mp3" },
  { id: "taunt", name: "তামাশা", line: "এত কাছে মিস", src: "/voices/taunt.mp3" },
];

export function effectById(id: string): Effect {
  return EFFECTS.find((effect) => effect.id === id) ?? EFFECTS[0];
}
