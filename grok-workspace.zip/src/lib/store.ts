import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

export type TargetKind = "battle" | "chat" | "generic";

export type Target = {
  id: string;
  name: string;
  kind: TargetKind;
  builtIn: boolean;
};

export type CustomVoice = {
  id: string;
  name: string;
};

type BoothState = {
  targets: Target[];
  custom: CustomVoice[];
  effectId: string;
  orb: { x: number; y: number };
  volume: number;
  hintSeen: boolean;
  view: "home" | "stage";
  activeId: string | null;
  sheet: boolean;
  playingId: string | null;
  live: boolean;
  micError: string | null;
  audioUrls: Record<string, string>;
  imageUrls: Record<string, string>;
  setHydratedMedia: (audioUrls: Record<string, string>, imageUrls: Record<string, string>) => void;
  setOrb: (orb: { x: number; y: number }) => void;
  markHint: () => void;
  setEffectId: (id: string) => void;
  setVolume: (volume: number) => void;
  setSheet: (sheet: boolean) => void;
  setPlaying: (id: string | null) => void;
  setLive: (live: boolean) => void;
  setMicError: (micError: string | null) => void;
  enter: (id: string) => void;
  leave: () => void;
  addTarget: (name: string, kind: TargetKind) => void;
  removeTarget: (id: string) => void;
  addCustom: (voice: CustomVoice, audioUrl: string, imageUrl?: string) => void;
  setVoiceImage: (id: string, imageUrl: string) => void;
  removeCustom: (id: string) => void;
};

const DEFAULT_TARGETS: Target[] = [
  { id: "ff", name: "Free Fire", kind: "battle", builtIn: true },
  { id: "ffm", name: "Free Fire MAX", kind: "battle", builtIn: true },
  { id: "wa", name: "WhatsApp", kind: "chat", builtIn: true },
];

export const useBooth = create<BoothState>()(
  persist(
    (set) => ({
      targets: DEFAULT_TARGETS,
      custom: [],
      effectId: "dry",
      orb: { x: 0.86, y: 0.74 },
      volume: 0.9,
      hintSeen: false,
      view: "home",
      activeId: null,
      sheet: false,
      playingId: null,
      live: false,
      micError: null,
      audioUrls: {},
      imageUrls: {},
      setHydratedMedia: (audioUrls, imageUrls) => set({ audioUrls, imageUrls }),
      setOrb: (orb) => set({ orb }),
      markHint: () => set({ hintSeen: true }),
      setEffectId: (effectId) => set({ effectId }),
      setVolume: (volume) => set({ volume }),
      setSheet: (sheet) => set({ sheet }),
      setPlaying: (playingId) => set({ playingId }),
      setLive: (live) => set({ live }),
      setMicError: (micError) => set({ micError }),
      enter: (activeId) => set({ activeId, view: "stage", sheet: false, micError: null }),
      leave: () => set({ view: "home", sheet: false, playingId: null }),
      addTarget: (name, kind) =>
        set((state) => ({
          targets: [
            ...state.targets,
            { id: crypto.randomUUID(), name, kind, builtIn: false },
          ],
        })),
      removeTarget: (id) =>
        set((state) => ({
          targets: state.targets.filter((target) => target.builtIn || target.id !== id),
        })),
      addCustom: (voice, audioUrl, imageUrl) =>
        set((state) => ({
          custom: [...state.custom, voice],
          audioUrls: { ...state.audioUrls, [voice.id]: audioUrl },
          imageUrls: imageUrl ? { ...state.imageUrls, [voice.id]: imageUrl } : state.imageUrls,
        })),
      setVoiceImage: (id, imageUrl) =>
        set((state) => {
          const prev = state.imageUrls[id];
          if (prev) URL.revokeObjectURL(prev);
          return { imageUrls: { ...state.imageUrls, [id]: imageUrl } };
        }),
      removeCustom: (id) =>
        set((state) => {
          const audio = state.audioUrls[id];
          const image = state.imageUrls[id];
          if (audio?.startsWith("blob:")) URL.revokeObjectURL(audio);
          if (image) URL.revokeObjectURL(image);
          const audioUrls = { ...state.audioUrls };
          const imageUrls = { ...state.imageUrls };
          delete audioUrls[id];
          delete imageUrls[id];
          return {
            custom: state.custom.filter((voice) => voice.id !== id),
            audioUrls,
            imageUrls,
            playingId: state.playingId === id ? null : state.playingId,
          };
        }),
    }),
    {
      name: "kantho-booth",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (state) => ({
        targets: state.targets,
        custom: state.custom,
        effectId: state.effectId,
        orb: state.orb,
        volume: state.volume,
        hintSeen: state.hintSeen,
      }),
    },
  ),
);
