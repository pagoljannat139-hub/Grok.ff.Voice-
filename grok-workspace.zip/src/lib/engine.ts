import { effectById, type Effect } from "@/lib/presets";

function curve(drive: number) {
  if (drive <= 1.05) return null;
  const n = 256;
  const data = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1;
    data[i] = Math.tanh(x * drive);
  }
  return data;
}

function micMessage(err: unknown) {
  const name = err instanceof DOMException ? err.name : "";
  if (name === "NotAllowedError" || name === "SecurityError") {
    return "মাইকের অনুমতি দেওয়া হয়নি।";
  }
  if (name === "NotFoundError") return "এই ডিভাইসে মাইক নেই।";
  return "মাইক চালু করা যায়নি।";
}

export function pickMime() {
  if (typeof MediaRecorder === "undefined") return undefined;
  const types = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"];
  return types.find((type) => MediaRecorder.isTypeSupported(type));
}

export class Engine {
  analyser: AnalyserNode | null = null;
  onEnded: (() => void) | null = null;

  private ctx: AudioContext | null = null;
  private pitch: AudioWorkletNode | null = null;
  private micGain: GainNode | null = null;
  private filter: BiquadFilterNode | null = null;
  private shaper: WaveShaperNode | null = null;
  private delay: DelayNode | null = null;
  private feedback: GainNode | null = null;
  private clipGain: GainNode | null = null;
  private master: GainNode | null = null;
  private source: MediaStreamAudioSourceNode | null = null;
  private stream: MediaStream | null = null;
  private clip: AudioBufferSourceNode | null = null;
  private cache = new Map<string, AudioBuffer>();
  private volume = 0.9;
  private live = false;
  private ready: Promise<void> | null = null;
  private effect: Effect = effectById("dry");
  private rec: MediaRecorder | null = null;
  private recStream: MediaStream | null = null;
  private chunks: Blob[] = [];

  setVolume(value: number) {
    this.volume = value;
    this.master?.gain.setTargetAtTime(value, this.ctx?.currentTime ?? 0, 0.03);
  }

  private async build() {
    if (this.ctx) return;
    const ctx = new AudioContext();
    this.ctx = ctx;
    try {
      await ctx.audioWorklet.addModule("/worklets/pitch.js");
      this.pitch = new AudioWorkletNode(ctx, "kantho-pitch");
    } catch {
      this.pitch = null;
    }

    this.micGain = ctx.createGain();
    this.micGain.gain.value = 0;
    this.filter = ctx.createBiquadFilter();
    this.shaper = ctx.createWaveShaper();
    this.shaper.oversample = "2x";
    this.shaper.curve = curve(1);
    this.delay = ctx.createDelay(1.2);
    this.feedback = ctx.createGain();
    this.feedback.gain.value = 0;
    this.clipGain = ctx.createGain();
    this.master = ctx.createGain();
    this.master.gain.value = this.volume;
    const comp = ctx.createDynamicsCompressor();
    comp.threshold.value = -16;
    comp.knee.value = 10;
    comp.ratio.value = 3;
    comp.attack.value = 0.008;
    comp.release.value = 0.18;
    this.analyser = ctx.createAnalyser();
    this.analyser.fftSize = 512;

    if (this.pitch) {
      this.micGain.connect(this.pitch);
      this.pitch.connect(this.filter);
    } else {
      this.micGain.connect(this.filter);
    }
    this.filter.connect(this.shaper);
    this.shaper.connect(this.delay);
    this.delay.connect(this.feedback);
    this.feedback.connect(this.delay);
    this.delay.connect(comp);
    this.clipGain.connect(comp);
    comp.connect(this.master);
    this.master.connect(this.analyser);
    this.analyser.connect(ctx.destination);
    this.applyEffect(this.effect);
  }

  private async ensure() {
    if (!this.ready) this.ready = this.build();
    await this.ready;
    if (this.ctx?.state === "suspended") await this.ctx.resume();
  }

  applyEffect(effect: Effect) {
    this.effect = effect;
    this.pitch?.port.postMessage({
      semitones: effect.semitones,
      ring: effect.ring,
      ringHz: effect.ringHz,
    });
    const now = this.ctx?.currentTime ?? 0;
    if (!this.filter || !this.delay || !this.feedback || !this.shaper) return;
    this.filter.type = effect.filter.type;
    this.filter.frequency.setTargetAtTime(effect.filter.freq, now, 0.02);
    this.filter.Q.setTargetAtTime(effect.filter.q, now, 0.02);
    this.filter.gain.setTargetAtTime(effect.filter.gain, now, 0.02);
    this.delay.delayTime.setTargetAtTime(Math.max(0, effect.delay), now, 0.02);
    this.feedback.gain.setTargetAtTime(effect.feedback, now, 0.02);
    this.shaper.curve = curve(effect.drive);
  }

  async setEffect(id: string) {
    const effect = effectById(id);
    this.effect = effect;
    if (this.ctx) {
      await this.ensure();
      this.applyEffect(effect);
    }
  }

  async startLive() {
    await this.ensure();
    if (!this.ctx || !this.micGain) return;
    if (!this.stream) {
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
          video: false,
        });
      } catch (err) {
        throw new Error(micMessage(err));
      }
    }
    this.source?.disconnect();
    this.source = this.ctx.createMediaStreamSource(this.stream);
    this.source.connect(this.micGain);
    this.live = true;
    this.micGain.gain.setTargetAtTime(1, this.ctx.currentTime, 0.03);
    this.applyEffect(this.effect);
  }

  stopLive() {
    this.live = false;
    this.source?.disconnect();
    this.source = null;
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = null;
    if (this.micGain && this.ctx) {
      this.micGain.gain.setTargetAtTime(0, this.ctx.currentTime, 0.02);
    }
  }

  async play(url: string) {
    await this.ensure();
    if (!this.ctx || !this.clipGain) return;
    let buffer = this.cache.get(url);
    if (!buffer) {
      const response = await fetch(url);
      if (!response.ok) throw new Error("ক্লিপ লোড হয়নি।");
      const raw = await response.arrayBuffer();
      buffer = await this.ctx.decodeAudioData(raw.slice(0));
      this.cache.set(url, buffer);
    }
    this.stopClip();
    const src = this.ctx.createBufferSource();
    src.buffer = buffer;
    src.connect(this.clipGain);
    src.onended = () => {
      if (this.clip !== src) return;
      this.clip = null;
      if (this.live && this.micGain && this.ctx) {
        this.micGain.gain.setTargetAtTime(1, this.ctx.currentTime, 0.04);
      }
      this.onEnded?.();
    };
    if (this.live && this.micGain) {
      this.micGain.gain.setTargetAtTime(0.12, this.ctx.currentTime, 0.03);
    }
    src.start();
    this.clip = src;
  }

  stopClip() {
    if (!this.clip) return;
    const current = this.clip;
    this.clip = null;
    try {
      current.stop();
    } catch {
      /* already stopped */
    }
  }

  async beginRecord() {
    if (this.live) this.stopLive();
    const mime = pickMime();
    try {
      this.recStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
    } catch (err) {
      throw new Error(micMessage(err));
    }
    this.chunks = [];
    this.rec = new MediaRecorder(this.recStream, mime ? { mimeType: mime } : undefined);
    this.rec.ondataavailable = (event) => {
      if (event.data.size > 0) this.chunks.push(event.data);
    };
    this.rec.start();
  }

  endRecord(): Promise<Blob> {
    const rec = this.rec;
    if (!rec) return Promise.reject(new Error("রেকর্ড চালু নেই।"));
    return new Promise((resolve, reject) => {
      rec.onstop = () => {
        const blob = new Blob(this.chunks, { type: rec.mimeType || "audio/webm" });
        this.recStream?.getTracks().forEach((track) => track.stop());
        this.recStream = null;
        this.rec = null;
        this.chunks = [];
        resolve(blob);
      };
      rec.onerror = () => reject(new Error("রেকর্ড থেমে গেছে।"));
      rec.stop();
    });
  }

  async decode(blob: Blob) {
    await this.ensure();
    if (!this.ctx) throw new Error("অডিও চালু হয়নি।");
    const copy = (await blob.arrayBuffer()).slice(0);
    await this.ctx.decodeAudioData(copy);
  }
}

let singleton: Engine | null = null;

export function getEngine() {
  if (!singleton) singleton = new Engine();
  return singleton;
}
