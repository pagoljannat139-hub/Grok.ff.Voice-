function hash(id: string) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 33 + id.charCodeAt(i)) >>> 0;
  return h;
}

function Marks({ id }: { id: string }) {
  const kind = hash(id) % 6;
  if (kind === 0) {
    return (
      <g fill="none" stroke="currentColor" strokeWidth="1.4">
        <path d="M22 46 L40 30 L58 46" />
        <path d="M26 54 L40 40 L54 54" />
      </g>
    );
  }
  if (kind === 1) {
    return (
      <g fill="none" stroke="currentColor" strokeWidth="1.4">
        <circle cx="40" cy="40" r="16" />
        <circle cx="40" cy="40" r="24" />
      </g>
    );
  }
  if (kind === 2) {
    const ticks = Array.from({ length: 8 }, (_, i) => {
      const a = (Math.PI * 2 * i) / 8;
      const x1 = 40 + Math.cos(a) * 22;
      const y1 = 40 + Math.sin(a) * 22;
      const x2 = 40 + Math.cos(a) * 28;
      const y2 = 40 + Math.sin(a) * 28;
      return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} />;
    });
    return (
      <g fill="none" stroke="currentColor" strokeWidth="1.6">
        {ticks}
      </g>
    );
  }
  if (kind === 3) {
    return (
      <g fill="none" stroke="currentColor" strokeWidth="1.4">
        <rect x="24" y="24" width="32" height="32" transform="rotate(45 40 40)" />
      </g>
    );
  }
  if (kind === 4) {
    return (
      <g fill="none" stroke="currentColor" strokeWidth="1.4">
        <path d="M18 46c8-14 36-14 44 0" />
        <path d="M18 34c8-14 36-14 44 0" />
      </g>
    );
  }
  return (
    <g fill="none" stroke="currentColor" strokeWidth="1.4">
      <path d="M24 56 L56 24" />
      <circle cx="40" cy="40" r="18" />
    </g>
  );
}

export function Seal({ id, name, image }: { id: string; name: string; image?: string }) {
  if (image) {
    return <img src={image} alt="" className="size-full object-cover" />;
  }
  const letter = name.trim().slice(0, 1) || "ক";
  return (
    <svg viewBox="0 0 80 80" className="size-full text-primary" aria-hidden>
      <circle cx="40" cy="40" r="40" className="fill-surface-2" />
      <Marks id={id} />
      <circle cx="40" cy="42" r="15" className="fill-surface-2" />
      <text
        x="40"
        y="47"
        textAnchor="middle"
        fontSize="20"
        fontWeight="600"
        className="fill-fg"
        fontFamily="Noto Sans Bengali, sans-serif"
      >
        {letter}
      </text>
    </svg>
  );
}
