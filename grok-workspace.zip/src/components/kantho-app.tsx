import { useEffect, useRef, useState, type PointerEvent, type ReactNode } from "react";
import {
  ChevronLeft,
  Crosshair,
  Headphones,
  ImagePlus,
  MessageCircle,
  Mic,
  Plus,
  Radio,
  Square,
  X,
} from "lucide-react";
import { Seal } from "@/components/seal";
import { getEngine } from "@/lib/engine";
import { audioKey, idbDel, idbGet, idbSet, imageKey, shrinkImage } from "@/lib/idb";
import { EFFECTS, PRESETS, effectById } from "@/lib/presets";
import { useBooth, type TargetKind } from "@/lib/store";

function clock(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

function kindIcon(kind: TargetKind) {
  if (kind === "battle") return Crosshair;
  if (kind === "chat") return MessageCircle;
  return Radio;
}

export function KanthoApp() {
  const view = useBooth((s) => s.view);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const finish = () => setReady(true);
    const unsub = useBooth.persist.onFinishHydration(finish);
    if (useBooth.persist.hasHydrated()) finish();
    else void useBooth.persist.rehydrate();
    return unsub;
  }, []);

  useEffect(() => {
    if (!ready) return;
    let cancel = false;
    void (async () => {
      const voices = useBooth.getState().custom;
      const audioUrls: Record<string, string> = {};
      const imageUrls: Record<string, string> = {};
      for (const voice of voices) {
        const audio = await idbGet(audioKey(voice.id));
        const image = await idbGet(imageKey(voice.id));
        if (audio) audioUrls[voice.id] = URL.createObjectURL(audio);
        if (image) imageUrls[voice.id] = URL.createObjectURL(image);
      }
      if (!cancel) useBooth.getState().setHydratedMedia(audioUrls, imageUrls);
    })();
    return () => {
      cancel = true;
    };
  }, [ready]);

  useEffect(() => {
    const volume = useBooth.getState().volume;
    getEngine().setVolume(volume);
    return useBooth.subscribe((state, prev) => {
      if (state.volume !== prev.volume) getEngine().setVolume(state.volume);
    });
  }, []);

  return (
    <div className="relative mx-auto flex h-dvh w-full max-w-lg flex-col overflow-hidden bg-bg md:my-6 md:h-[calc(100dvh-3rem)] md:rounded-card md:border md:border-line md:shadow-phone">
      {view === "home" ? <Home /> : <Stage />}
    </div>
  );
}

function Home() {
  const targets = useBooth((s) => s.targets);
  const custom = useBooth((s) => s.custom);
  const imageUrls = useBooth((s) => s.imageUrls);
  const audioUrls = useBooth((s) => s.audioUrls);
  const playingId = useBooth((s) => s.playingId);
  const enter = useBooth((s) => s.enter);
  const removeTarget = useBooth((s) => s.removeTarget);
  const [addingApp, setAddingApp] = useState(false);
  const [addingVoice, setAddingVoice] = useState(false);
  const [photoFor, setPhotoFor] = useState<string | null>(null);

  return (
    <div className="flex min-h-0 flex-1 flex-col">
      <div className="min-h-0 flex-1 overflow-y-auto px-5 pt-7 pb-6">
        <p className="text-xs font-semibold tracking-widest text-primary">VOICE BOOTH</p>
        <h1 className="mt-1 font-display text-5xl leading-none font-bold">কণ্ঠ</h1>
        <p className="mt-3 max-w-sm text-muted">
          অ্যাপ বেছে নাও, ভাসমান গোলটা টেনে সরাও, ক্লিপে ছবি বসাও। নিজের গলাও বদলানো যায়।
        </p>

        <section className="mt-8">
          <div className="mb-3 flex items-end justify-between">
            <h2 className="font-display text-xl font-semibold">অ্যাপ</h2>
            <button
              type="button"
              onClick={() => setAddingApp(true)}
              className="inline-flex h-11 items-center gap-1 rounded-full px-3 text-sm text-primary"
            >
              <Plus className="size-4" />
              যোগ
            </button>
          </div>
          <ul className="grid grid-cols-2 gap-3">
            {targets.map((target) => {
              const Icon = kindIcon(target.kind);
              return (
                <li key={target.id} className="relative">
                  <button
                    type="button"
                    onClick={() => enter(target.id)}
                    className="flex h-full w-full flex-col items-start gap-4 rounded-card border border-line bg-surface p-4 text-left"
                  >
                    <span className="grid size-11 place-items-center rounded-full bg-surface-2 text-primary">
                      <Icon className="size-5" />
                    </span>
                    <span>
                      <span className="block font-display text-lg leading-tight font-semibold">
                        {target.name}
                      </span>
                      <span className="text-sm text-muted">ঢোকো</span>
                    </span>
                  </button>
                  {!target.builtIn && (
                    <button
                      type="button"
                      aria-label={`${target.name} মুছে ফেলো`}
                      onClick={() => removeTarget(target.id)}
                      className="absolute top-2 right-2 grid size-9 place-items-center rounded-full text-muted"
                    >
                      <X className="size-4" />
                    </button>
                  )}
                </li>
              );
            })}
          </ul>
        </section>

        <section className="mt-9">
          <h2 className="font-display text-xl font-semibold">ভয়েস</h2>
          <p className="mt-1 text-sm text-muted">টিপলে বাজবে। নিচ থেকে নিজেরটা যোগ করো, উপরে ছবি বসবে।</p>
          <ul className="mt-4 grid grid-cols-3 gap-x-2 gap-y-5">
            {PRESETS.map((voice) => (
              <VoiceCell
                key={voice.id}
                id={voice.id}
                name={voice.name}
                line={voice.line}
                src={voice.src}
                playing={playingId === voice.id}
              />
            ))}
            {custom.map((voice) => (
              <VoiceCell
                key={voice.id}
                id={voice.id}
                name={voice.name}
                line="তোমার ক্লিপ"
                src={audioUrls[voice.id] ?? ""}
                image={imageUrls[voice.id]}
                playing={playingId === voice.id}
                custom
                onPhoto={() => setPhotoFor(voice.id)}
              />
            ))}
          </ul>
        </section>

        <details className="mt-8 rounded-card border border-line bg-surface px-4 py-3 text-sm text-muted">
          <summary className="font-semibold text-fg">এটা কীভাবে কাজ করে</summary>
          <p className="mt-2">
            কণ্ঠ তোমার ক্লিপ আর বদলানো গলা এই বুথে বাজায়। Free Fire বা WhatsApp-এর ভিতরের মাইক একটা সাধারণ
            অ্যাপ পাল্টাতে পারে না — সেটা ফোনের নিরাপত্তা, তাই এখানে হ্যাক বা লুকানো হুক নেই। স্পিকারে বাজালে
            কাছের মাইক শুনতে পারে। লাইভ বদল শুনতে ইয়ারফোন পরো।
          </p>
        </details>
      </div>

      <div className="shrink-0 border-t border-line bg-bg px-4 py-4">
        <button
          type="button"
          onClick={() => setAddingVoice(true)}
          className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary font-semibold text-primary-fg"
        >
          <Plus className="size-5" />
          ভয়েস যোগ
        </button>
      </div>

      {addingApp && <AddTarget onClose={() => setAddingApp(false)} />}
      {addingVoice && <AddVoice onClose={() => setAddingVoice(false)} />}
      {photoFor && <PhotoSwap id={photoFor} onClose={() => setPhotoFor(null)} />}
    </div>
  );
}

function VoiceCell({
  id,
  name,
  line,
  src,
  image,
  playing,
  custom,
  onPhoto,
}: {
  id: string;
  name: string;
  line: string;
  src: string;
  image?: string;
  playing: boolean;
  custom?: boolean;
  onPhoto?: () => void;
}) {
  return (
    <li className="flex flex-col items-center text-center">
      <button
        type="button"
        aria-label={`${name} বাজাও`}
        onClick={() => void playVoice(id, src)}
        className={`size-20 overflow-hidden rounded-full border-2 ${playing ? "border-primary" : "border-line"}`}
      >
        <Seal id={id} name={name} image={image} />
      </button>
      <p className={`mt-2 text-sm font-semibold ${playing ? "text-primary" : "text-fg"}`}>{name}</p>
      <p className="line-clamp-2 text-xs text-muted">{playing ? "বাজছে" : line}</p>
      {custom && (
        <div className="mt-1 flex gap-2">
          <button type="button" onClick={onPhoto} className="text-xs text-primary">
            ছবি
          </button>
          <button type="button" onClick={() => void removeVoice(id)} className="text-xs text-muted">
            মুছো
          </button>
        </div>
      )}
    </li>
  );
}

async function playVoice(id: string, src: string) {
  const booth = useBooth.getState();
  if (!src) {
    booth.setMicError("এই ভয়েসে কোনো রেকর্ড নেই।");
    return;
  }
  booth.setMicError(null);
  if (booth.playingId === id) {
    getEngine().stopClip();
    booth.setPlaying(null);
    return;
  }
  try {
    getEngine().onEnded = () => useBooth.getState().setPlaying(null);
    await getEngine().play(src);
    useBooth.getState().setPlaying(id);
  } catch {
    useBooth.getState().setPlaying(null);
    useBooth.getState().setMicError("ক্লিপ বাজানো যায়নি।");
  }
}

async function removeVoice(id: string) {
  if (useBooth.getState().playingId === id) getEngine().stopClip();
  useBooth.getState().removeCustom(id);
  await idbDel(audioKey(id));
  await idbDel(imageKey(id));
}

function Stage() {
  const activeId = useBooth((s) => s.activeId);
  const targets = useBooth((s) => s.targets);
  const target = targets.find((item) => item.id === activeId) ?? targets[0];
  const leave = useBooth((s) => s.leave);
  const orb = useBooth((s) => s.orb);
  const setOrb = useBooth((s) => s.setOrb);
  const sheet = useBooth((s) => s.sheet);
  const setSheet = useBooth((s) => s.setSheet);
  const hintSeen = useBooth((s) => s.hintSeen);
  const markHint = useBooth((s) => s.markHint);
  const live = useBooth((s) => s.live);
  const setLive = useBooth((s) => s.setLive);
  const micError = useBooth((s) => s.micError);
  const setMicError = useBooth((s) => s.setMicError);
  const effectId = useBooth((s) => s.effectId);
  const playingId = useBooth((s) => s.playingId);
  const volume = useBooth((s) => s.volume);
  const setVolume = useBooth((s) => s.setVolume);
  const custom = useBooth((s) => s.custom);
  const stageRef = useRef<HTMLDivElement>(null);
  const orbRef = useRef<HTMLButtonElement>(null);
  const drag = useRef<{ x: number; y: number; ox: number; oy: number; moved: boolean } | null>(null);
  const [sec, setSec] = useState(0);
  const [addingVoice, setAddingVoice] = useState(false);

  useEffect(() => {
    const id = window.setInterval(() => setSec((value) => value + 1), 1000);
    return () => window.clearInterval(id);
  }, []);

  useEffect(() => {
    if (!live && !playingId) return;
    let frame = 0;
    const data = new Uint8Array(512);
    const loop = () => {
      frame = requestAnimationFrame(loop);
      const analyser = getEngine().analyser;
      const node = orbRef.current;
      if (!analyser || !node) return;
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) {
        const v = (data[i] - 128) / 128;
        sum += v * v;
      }
      node.style.setProperty("--level", Math.min(1, Math.sqrt(sum / data.length) * 4).toFixed(3));
    };
    loop();
    return () => cancelAnimationFrame(frame);
  }, [live, playingId]);

  useEffect(() => {
    return () => {
      getEngine().stopClip();
      getEngine().stopLive();
      useBooth.getState().setLive(false);
      useBooth.getState().setPlaying(null);
    };
  }, []);

  const visualY = sheet ? 0.18 : orb.y;
  const effect = effectById(effectId);
  const playing =
    PRESETS.find((voice) => voice.id === playingId) ??
    custom.find((voice) => voice.id === playingId);

  function onPointerDown(event: PointerEvent<HTMLButtonElement>) {
    event.currentTarget.setPointerCapture(event.pointerId);
    drag.current = { x: event.clientX, y: event.clientY, ox: orb.x, oy: visualY, moved: false };
  }

  function onPointerMove(event: PointerEvent<HTMLButtonElement>) {
    const start = drag.current;
    const stage = stageRef.current;
    if (!start || !stage) return;
    const dx = event.clientX - start.x;
    const dy = event.clientY - start.y;
    if (Math.hypot(dx, dy) > 6) start.moved = true;
    const rect = stage.getBoundingClientRect();
    setOrb({
      x: clamp(start.ox + dx / rect.width, 0.1, 0.9),
      y: clamp(start.oy + dy / rect.height, 0.14, 0.86),
    });
  }

  function onPointerUp() {
    const start = drag.current;
    drag.current = null;
    if (!start) return;
    if (start.moved) {
      if (!hintSeen) markHint();
      return;
    }
    setSheet(!useBooth.getState().sheet);
  }

  async function toggleLive() {
    if (live) {
      getEngine().stopLive();
      setLive(false);
      return;
    }
    try {
      await getEngine().setEffect(effectId);
      await getEngine().startLive();
      setLive(true);
      setMicError(null);
    } catch (err) {
      setLive(false);
      setMicError(err instanceof Error ? err.message : "মাইক চালু করা যায়নি।");
    }
  }

  async function armEffect(id: string) {
    useBooth.getState().setEffectId(id);
    await getEngine().setEffect(id);
    if (id === "dry") {
      getEngine().stopClip();
      useBooth.getState().setPlaying(null);
    }
    if (!useBooth.getState().live) {
      try {
        await getEngine().startLive();
        useBooth.getState().setLive(true);
        useBooth.getState().setMicError(null);
      } catch (err) {
        useBooth.getState().setMicError(err instanceof Error ? err.message : "মাইক চালু করা যায়নি।");
      }
    }
  }

  return (
    <div ref={stageRef} className={`relative min-h-0 flex-1 overflow-hidden ${stageClass(target?.kind)}`}>
      <header className="flex items-center gap-2 px-3 pt-4">
        <button
          type="button"
          onClick={() => {
            getEngine().stopClip();
            getEngine().stopLive();
            setLive(false);
            leave();
          }}
          className="grid size-11 place-items-center rounded-full bg-surface text-fg"
          aria-label="ফিরে যাও"
        >
          <ChevronLeft className="size-5" />
        </button>
        <div className="min-w-0 flex-1">
          <p className="truncate font-display text-lg leading-tight font-semibold">{target?.name}</p>
          <p className="text-xs text-muted">{target?.kind === "chat" ? "ভয়েস কল" : "স্কোয়াড চ্যানেল"} · {clock(sec)}</p>
        </div>
        <button
          type="button"
          aria-pressed={live}
          onClick={() => void toggleLive()}
          className={`inline-flex h-11 items-center gap-2 rounded-full px-3 text-sm font-semibold ${live ? "bg-live text-primary-fg" : "bg-surface text-fg"}`}
        >
          <Mic className="size-4" />
          {live ? "লাইভ" : "মাইক"}
        </button>
      </header>

      <div className="px-5 pt-6">
        {target?.kind === "chat" ? <ChatScene /> : <SquadScene you={effect.name} />}
        {playing && (
          <p className="mt-5 inline-flex items-center gap-2 rounded-full bg-surface px-3 py-1 text-sm text-primary">
            বাজছে · {playing.name}
          </p>
        )}
        {live && (
          <p className="mt-3 flex items-center gap-2 text-sm text-muted">
            <Headphones className="size-4 text-primary" />
            ইয়ারফোন পরো। গলা এখন «{effect.name}»।
          </p>
        )}
        {micError && <p className="mt-3 text-sm text-live">{micError}</p>}
      </div>

      {!hintSeen && !sheet && (
        <p
          className="pointer-events-none absolute z-20 -translate-x-full -translate-y-1/2 rounded-full bg-surface px-3 py-1 text-xs text-muted"
          style={{ left: `calc(${orb.x * 100}% - 0.75rem)`, top: `${visualY * 100}%` }}
        >
          টেনে সরাও
        </p>
      )}

      <button
        ref={orbRef}
        type="button"
        aria-label={sheet ? "ভয়েস বন্ধ করো" : "ভয়েস খোলো"}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        className="orb-core absolute z-30 grid size-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-primary text-primary-fg"
        style={{
          left: `${orb.x * 100}%`,
          top: `${visualY * 100}%`,
          boxShadow: "0 0 0 calc(var(--level, 0) * 1.1rem) color-mix(in oklab, var(--color-primary) 35%, transparent)",
          touchAction: "none",
        }}
      >
        {(live || playingId) && <span className="orb-ping absolute inset-0 rounded-full border-2 border-primary" />}
        <Mic className="relative size-7" />
      </button>

      {sheet && (
        <button
          type="button"
          aria-label="বন্ধ"
          className="absolute inset-0 z-10 bg-bg-deep/50"
          onClick={() => setSheet(false)}
        />
      )}

      <div
        className={`absolute inset-x-0 bottom-0 z-20 flex max-h-[72%] flex-col rounded-t-3xl border-t border-line bg-surface transition-transform duration-200 ${sheet ? "translate-y-0" : "translate-y-full"}`}
      >
        <div className="flex items-center justify-between px-5 pt-4 pb-2">
          <div>
            <h2 className="font-display text-xl font-semibold">ভয়েস</h2>
            <p className="text-xs text-muted">রেগুলার হোম মানে তোমার নিজের গলা</p>
          </div>
          <button type="button" aria-label="বন্ধ করো" onClick={() => setSheet(false)} className="grid size-11 place-items-center rounded-full bg-surface-2">
            <X className="size-5" />
          </button>
        </div>
        <div className="min-h-0 flex-1 overflow-y-auto px-5 pb-4">
          <p className="text-xs font-semibold tracking-widest text-muted">গলা</p>
          <div className="mt-2 flex gap-2 overflow-x-auto pb-2">
            {EFFECTS.map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => void armEffect(item.id)}
                className={`flex h-14 shrink-0 flex-col items-start justify-center rounded-2xl px-3 text-sm leading-tight font-semibold ${item.id === effectId ? "bg-primary text-primary-fg" : "bg-surface-2 text-fg"}`}
              >
                {item.name}
                <span className={`text-xs font-normal ${item.id === effectId ? "text-primary-fg" : "text-muted"}`}>
                  {item.hint}
                </span>
              </button>
            ))}
          </div>
          <p className="mt-4 text-xs font-semibold tracking-widest text-muted">ক্লিপ</p>
          <VoiceGrid onAdd={() => setAddingVoice(true)} />
          <label className="mt-5 flex items-center gap-3 text-sm text-muted">
            আওয়াজ
            <input
              type="range"
              min={0}
              max={1}
              step={0.01}
              value={volume}
              onChange={(event) => setVolume(Number(event.target.value))}
              className="h-11 flex-1 accent-primary"
            />
          </label>
        </div>
      </div>
      {addingVoice && <AddVoice onClose={() => setAddingVoice(false)} />}
    </div>
  );
}

function stageClass(kind: TargetKind | undefined) {
  if (kind === "battle") return "stage-battle";
  if (kind === "chat") return "stage-chat";
  return "bg-bg";
}

function SquadScene({ you }: { you: string }) {
  const rows = [
    { name: "তুমি", note: you, on: true },
    { name: "নীলা", note: "চুপ", on: false },
    { name: "সাজিদ", note: "মাইক বন্ধ", on: false },
  ];
  return (
    <div>
      <p className="text-sm text-muted">ম্যাচ চলছে। গোলটাতে টিপ দিলে ভয়েস খুলবে।</p>
      <ul className="mt-4 space-y-2">
        {rows.map((row) => (
          <li key={row.name} className="flex items-center gap-3 rounded-card border border-line bg-surface/80 px-3 py-3">
            <span className={`size-2.5 rounded-full ${row.on ? "bg-primary" : "bg-line"}`} />
            <span className="flex-1 font-semibold">{row.name}</span>
            <span className="text-sm text-muted">{row.note}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function ChatScene() {
  const thread = [
    { me: false, text: "মাইক অন করলে বলো।" },
    { me: true, text: "অন আছে। একটু শোনো।" },
    { me: false, text: "ক্লিপটা আবার দাও।" },
  ];
  return (
    <div className="space-y-2">
      {thread.map((item) => (
        <p
          key={item.text}
          className={`max-w-[80%] rounded-card px-3 py-2 text-sm ${item.me ? "ml-auto bg-primary text-primary-fg" : "bg-surface text-fg"}`}
        >
          {item.text}
        </p>
      ))}
    </div>
  );
}

function VoiceGrid({ onAdd }: { onAdd: () => void }) {
  const custom = useBooth((s) => s.custom);
  const imageUrls = useBooth((s) => s.imageUrls);
  const audioUrls = useBooth((s) => s.audioUrls);
  const playingId = useBooth((s) => s.playingId);
  const items = [
    ...PRESETS.map((voice) => ({ ...voice, image: undefined as string | undefined, custom: false })),
    ...custom.map((voice) => ({
      id: voice.id,
      name: voice.name,
      line: "তোমার ক্লিপ",
      src: audioUrls[voice.id] ?? "",
      image: imageUrls[voice.id],
      custom: true,
    })),
  ];
  return (
    <ul className="mt-2 grid grid-cols-4 gap-3">
      {items.map((voice) => (
        <li key={voice.id}>
          <button
            type="button"
            onClick={() => void playVoice(voice.id, voice.src)}
            className="flex w-full flex-col items-center gap-1"
          >
            <span className={`size-14 overflow-hidden rounded-full border-2 ${playingId === voice.id ? "border-primary" : "border-line"}`}>
              <Seal id={voice.id} name={voice.name} image={voice.image} />
            </span>
            <span className="w-full truncate text-center text-xs">{voice.name}</span>
          </button>
        </li>
      ))}
      <li>
        <button type="button" onClick={onAdd} className="flex w-full flex-col items-center gap-1">
          <span className="grid size-14 place-items-center rounded-full border-2 border-dashed border-line text-primary">
            <Plus className="size-5" />
          </span>
          <span className="text-xs text-muted">যোগ</span>
        </button>
      </li>
    </ul>
  );
}

function AddTarget({ onClose }: { onClose: () => void }) {
  const addTarget = useBooth((s) => s.addTarget);
  const [name, setName] = useState("");
  const [kind, setKind] = useState<TargetKind>("generic");
  const kinds: { id: TargetKind; label: string }[] = [
    { id: "battle", label: "গেম" },
    { id: "chat", label: "চ্যাট" },
    { id: "generic", label: "অন্য" },
  ];
  return (
    <Overlay title="অ্যাপ যোগ" onClose={onClose}>
      <label className="block text-sm text-muted">
        নাম
        <input
          value={name}
          onChange={(event) => setName(event.target.value.slice(0, 28))}
          placeholder="যেমন Telegram"
          className="mt-1 h-12 w-full rounded-card border border-line bg-bg px-3 text-fg"
        />
      </label>
      <div className="mt-4 flex gap-2">
        {kinds.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setKind(item.id)}
            className={`h-11 flex-1 rounded-full text-sm font-semibold ${kind === item.id ? "bg-primary text-primary-fg" : "bg-surface-2"}`}
          >
            {item.label}
          </button>
        ))}
      </div>
      <button
        type="button"
        disabled={!name.trim()}
        onClick={() => {
          addTarget(name.trim(), kind);
          onClose();
        }}
        className="mt-6 h-12 w-full rounded-full bg-primary font-semibold text-primary-fg disabled:opacity-40"
      >
        সেভ
      </button>
    </Overlay>
  );
}

function AddVoice({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState("");
  const [audio, setAudio] = useState<Blob | null>(null);
  const [image, setImage] = useState<Blob | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [recording, setRecording] = useState(false);
  const [sec, setSec] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const fileAudio = useRef<HTMLInputElement>(null);
  const fileImage = useRef<HTMLInputElement>(null);

  const stopRef = useRef<() => Promise<void>>(async () => {});

  useEffect(() => {
    if (!recording) return;
    const id = window.setInterval(() => setSec((value) => value + 1), 1000);
    return () => window.clearInterval(id);
  }, [recording]);

  useEffect(() => {
    if (recording && sec >= 8) void stopRef.current();
  }, [recording, sec]);

  useEffect(() => {
    return () => {
      if (imageUrl) URL.revokeObjectURL(imageUrl);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [imageUrl, previewUrl]);

  async function start() {
    setError(null);
    setSec(0);
    try {
      if (useBooth.getState().live) {
        getEngine().stopLive();
        useBooth.getState().setLive(false);
      }
      await getEngine().beginRecord();
      setRecording(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "রেকর্ড শুরু হয়নি।");
    }
  }

  async function stop() {
    if (!recording) return;
    setRecording(false);
    try {
      const blob = await getEngine().endRecord();
      await getEngine().decode(blob);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      setAudio(blob);
      setPreviewUrl(URL.createObjectURL(blob));
    } catch {
      setError("এই রেকর্ড বাজে না। আবার নাও।");
    }
  }

  stopRef.current = stop;

  async function onAudioFile(file: File) {
    setError(null);
    try {
      await getEngine().decode(file);
      if (previewUrl) URL.revokeObjectURL(previewUrl);
      setAudio(file);
      setPreviewUrl(URL.createObjectURL(file));
    } catch {
      setError("এই অডিও ফাইল চলবে না।");
    }
  }

  async function onImageFile(file: File) {
    const blob = await shrinkImage(file);
    if (imageUrl) URL.revokeObjectURL(imageUrl);
    setImage(blob);
    setImageUrl(URL.createObjectURL(blob));
  }

  async function save() {
    if (!name.trim() || !audio) return;
    setSaving(true);
    try {
      const id = crypto.randomUUID();
      await idbSet(audioKey(id), audio);
      if (image) await idbSet(imageKey(id), image);
      const audioUrl = URL.createObjectURL(audio);
      const nextImage = image ? URL.createObjectURL(image) : undefined;
      useBooth.getState().addCustom({ id, name: name.trim() }, audioUrl, nextImage);
      onClose();
    } catch {
      setError("সেভ হয়নি।");
      setSaving(false);
    }
  }

  return (
    <Overlay title="ভয়েস যোগ" onClose={onClose}>
      <label className="block text-sm text-muted">
        নাম
        <input
          value={name}
          onChange={(event) => setName(event.target.value.slice(0, 22))}
          placeholder="যেমন হাসি"
          className="mt-1 h-12 w-full rounded-card border border-line bg-bg px-3 text-fg"
        />
      </label>
      <div className="mt-4 flex items-center gap-4">
        <button
          type="button"
          onClick={() => fileImage.current?.click()}
          className="size-20 overflow-hidden rounded-full border-2 border-dashed border-line"
        >
          {imageUrl ? (
            <img src={imageUrl} alt="" className="size-full object-cover" />
          ) : (
            <span className="grid size-full place-items-center text-primary">
              <ImagePlus className="size-6" />
            </span>
          )}
        </button>
        <div>
          <p className="font-semibold">ছবি</p>
          <p className="text-sm text-muted">ভয়েসের উপরে বসবে</p>
        </div>
        <input
          ref={fileImage}
          type="file"
          accept="image/*"
          className="sr-only"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void onImageFile(file);
          }}
        />
      </div>
      <div className="mt-5 flex gap-2">
        <button
          type="button"
          onClick={() => void (recording ? stop() : start())}
          className={`inline-flex h-12 flex-1 items-center justify-center gap-2 rounded-full font-semibold ${recording ? "bg-live text-primary-fg" : "bg-surface-2 text-fg"}`}
        >
          {recording ? <Square className="size-4" /> : <Mic className="size-4" />}
          {recording ? `থামো ${sec}s` : "রেকর্ড"}
        </button>
        <button
          type="button"
          onClick={() => fileAudio.current?.click()}
          className="h-12 flex-1 rounded-full bg-surface-2 font-semibold"
        >
          ফাইল
        </button>
        <input
          ref={fileAudio}
          type="file"
          accept="audio/*"
          className="sr-only"
          onChange={(event) => {
            const file = event.target.files?.[0];
            if (file) void onAudioFile(file);
          }}
        />
      </div>
      <p className="mt-2 text-xs text-muted">রেকর্ড সর্বোচ্চ ৮ সেকেন্ড। সরাসরি মাইক থেকে।</p>
      {previewUrl && (
        <button
          type="button"
          onClick={() => void playVoice("preview", previewUrl)}
          className="mt-3 text-sm font-semibold text-primary"
        >
          শুনে দেখো
        </button>
      )}
      {error && <p className="mt-3 text-sm text-live">{error}</p>}
      <button
        type="button"
        disabled={!name.trim() || !audio || saving}
        onClick={() => void save()}
        className="mt-6 h-12 w-full rounded-full bg-primary font-semibold text-primary-fg disabled:opacity-40"
      >
        যোগ করো
      </button>
    </Overlay>
  );
}

function PhotoSwap({ id, onClose }: { id: string; onClose: () => void }) {
  const input = useRef<HTMLInputElement>(null);
  const [error, setError] = useState<string | null>(null);

  async function onFile(file: File) {
    try {
      const blob = await shrinkImage(file);
      await idbSet(imageKey(id), blob);
      useBooth.getState().setVoiceImage(id, URL.createObjectURL(blob));
      onClose();
    } catch {
      setError("ছবি বসানো যায়নি।");
    }
  }

  return (
    <Overlay title="ছবি বসাও" onClose={onClose}>
      <button
        type="button"
        onClick={() => input.current?.click()}
        className="flex h-12 w-full items-center justify-center gap-2 rounded-full bg-primary font-semibold text-primary-fg"
      >
        <ImagePlus className="size-5" />
        গ্যালারি থেকে নাও
      </button>
      <input
        ref={input}
        type="file"
        accept="image/*"
        className="sr-only"
        onChange={(event) => {
          const file = event.target.files?.[0];
          if (file) void onFile(file);
        }}
      />
      {error && <p className="mt-3 text-sm text-live">{error}</p>}
    </Overlay>
  );
}

function Overlay({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
}) {
  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-bg">
      <header className="flex items-center gap-2 px-3 pt-4">
        <button type="button" aria-label="বন্ধ" onClick={onClose} className="grid size-11 place-items-center rounded-full bg-surface">
          <X className="size-5" />
        </button>
        <h2 className="font-display text-xl font-semibold">{title}</h2>
      </header>
      <div className="flex-1 overflow-y-auto px-5 pt-5 pb-8">{children}</div>
    </div>
  );
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}
