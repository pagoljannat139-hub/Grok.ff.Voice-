import { createFileRoute } from "@tanstack/react-router";
import { KanthoApp } from "@/components/kantho-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <KanthoApp />;
}
