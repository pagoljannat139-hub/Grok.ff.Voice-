class KanthoPitch extends AudioWorkletProcessor {
  constructor() {
    super();
    this.size = 4096;
    this.data = new Float32Array(this.size);
    this.write = 0;
    this.phase = 0;
    this.semitones = 0;
    this.ring = 0;
    this.ringHz = 42;
    this.ringPhase = 0;
    this.port.onmessage = (event) => {
      const data = event.data || {};
      if (typeof data.semitones === "number") this.semitones = data.semitones;
      if (typeof data.ring === "number") this.ring = data.ring;
      if (typeof data.ringHz === "number") this.ringHz = data.ringHz;
    };
  }

  sample(pos) {
    const n = this.size;
    let p = pos % n;
    if (p < 0) p += n;
    const i0 = Math.floor(p);
    const i1 = (i0 + 1) % n;
    const f = p - i0;
    return this.data[i0] * (1 - f) + this.data[i1] * f;
  }

  process(inputs, outputs) {
    const input = inputs[0] && inputs[0][0];
    const output = outputs[0] && outputs[0][0];
    if (!input || !output) return true;

    if (Math.abs(this.semitones) < 0.05 && this.ring < 0.001) {
      output.set(input);
      return true;
    }

    const ratio = Math.pow(2, this.semitones / 12);
    const fade = 1024;
    const step = (1 - ratio) / fade;

    for (let i = 0; i < input.length; i++) {
      this.data[this.write] = input[i];
      this.phase += step;
      if (this.phase >= 1) this.phase -= 1;
      if (this.phase < 0) this.phase += 1;
      const phase2 = (this.phase + 0.5) % 1;
      const s1 = this.sample(this.write - this.phase * fade);
      const s2 = this.sample(this.write - phase2 * fade);
      const w1 = 0.5 * (1 - Math.cos(2 * Math.PI * this.phase));
      const w2 = 0.5 * (1 - Math.cos(2 * Math.PI * phase2));
      let sample = (s1 * w1 + s2 * w2) / (w1 + w2 || 1);

      if (this.ring > 0.001) {
        this.ringPhase += (2 * Math.PI * this.ringHz) / sampleRate;
        if (this.ringPhase > Math.PI * 2) this.ringPhase -= Math.PI * 2;
        const mod = Math.sin(this.ringPhase);
        sample = sample * (1 - this.ring) + sample * mod * this.ring;
      }

      output[i] = sample;
      this.write = (this.write + 1) % this.size;
    }

    const extra = outputs[0][1];
    if (extra) extra.set(output);
    return true;
  }
}

registerProcessor("kantho-pitch", KanthoPitch);
